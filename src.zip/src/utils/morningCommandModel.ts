/**
 * morningCommandModel.ts
 * Pure logic layer for Morning Command.
 * Derives risk state from portfolio intelligence — zero UI code.
 */

import type { RiskStateKey } from './morningCommandI18n'
import { getPortfolioIntelligence } from './portfolioIntelligence'
import { getPortfolioStorage } from './portfolioStorage'
import type { LanguageCode } from './language'

export type RiskLevel = 'low' | 'medium' | 'high'

export interface MorningCommandState {
  riskLevel: RiskLevel
  stateKey: RiskStateKey
  hasPortfolio: boolean
  topAssetLabel: string
  concentrationPct: number
  assetCount: number
}

/**
 * Map portfolioTone from intelligence to our tristate risk model.
 */
const toneToRiskLevel = (tone: string): RiskLevel => {
  switch (tone) {
    case 'bearish':
    case 'volatile':
      return 'high'
    case 'cautious':
      return 'medium'
    case 'neutral':
    case 'bullish':
    default:
      return 'low'
  }
}

const riskLevelToStateKey = (level: RiskLevel): RiskStateKey => {
  switch (level) {
    case 'high':
      return 'riskRising'
    case 'medium':
      return 'riskWatch'
    case 'low':
    default:
      return 'riskCalm'
  }
}

/**
 * Compute the morning command state from stored portfolio data.
 * This is the single function the UI calls.
 */
export const computeMorningCommandState = (language: LanguageCode): MorningCommandState => {
  const positions = getPortfolioStorage()

  if (!positions.length) {
    return {
      riskLevel: 'low',
      stateKey: 'riskCalm',
      hasPortfolio: false,
      topAssetLabel: '',
      concentrationPct: 0,
      assetCount: 0,
    }
  }

  // Build a minimal normalised portfolio for getPortfolioIntelligence
  const totalCurrentValue = positions.reduce((s, p) => s + (p.currentValue ?? 0), 0)
  const totalInvested = positions.reduce((s, p) => s + ((p.quantity ?? 0) * (p.entryPrice ?? 0)), 0)

  const mockPortfolio = {
    summary: {
      totalCurrentValue,
      totalInvested,
      totalPnl: totalCurrentValue - totalInvested,
      totalHoldings: positions.length,
    },
    holdings: positions.map(p => ({
      symbol: p.symbol,
      name: p.name,
      currentValue: p.currentValue ?? 0,
      quantity: p.quantity ?? 0,
      entryPrice: p.entryPrice ?? 0,
    })),
  }

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const intelligence = getPortfolioIntelligence(mockPortfolio as any, language)

  const tone = intelligence?.portfolioTone ?? 'neutral'
  const riskLevel = toneToRiskLevel(tone)
  const stateKey = riskLevelToStateKey(riskLevel)
  const topAssetLabel = intelligence?.largestPosition?.label ?? ''
  const concentrationPct = intelligence?.largestPosition?.weight ?? 0
  const assetCount = intelligence?.allocation?.length ?? 0

  return {
    riskLevel,
    stateKey,
    hasPortfolio: true,
    topAssetLabel,
    concentrationPct,
    assetCount,
  }
}
