const API_URL = import.meta.env.VITE_API_URL || ''

export interface MarketQuote {
  symbol: string
  name: string
  price: number
  changePercent: number
  change: number
  prevClose: number
  currency: string
  marketState: string
}

export interface MarketHistoryPoint {
  time: string
  price: number
}

export interface MarketNewsItem {
  title: string
  source: string
  url: string
  publishedAt: string
  summary: string
  symbols: string[]
}

export async function getMarketQuote(symbol: string): Promise<MarketQuote | null> {
  try {
    const res = await fetch(`${API_URL}/api/market/quote?symbol=${encodeURIComponent(symbol)}`)
    if (!res.ok) return null
    const json = await res.json()
    if (!json.ok || !json.data) return null
    return json.data as MarketQuote
  } catch (err) {
    return null
  }
}

export async function getMultipleMarketQuotes(symbols: string[]): Promise<MarketQuote[]> {
  const results = await Promise.allSettled(symbols.map(getMarketQuote))
  return results
    .filter((r): r is PromiseFulfilledResult<MarketQuote> => r.status === 'fulfilled' && r.value !== null)
    .map(r => r.value)
}

export async function getMarketHistory(symbol: string, range: string): Promise<MarketHistoryPoint[]> {
  try {
    const res = await fetch(`${API_URL}/api/market/history?symbol=${encodeURIComponent(symbol)}&range=${encodeURIComponent(range)}`)
    if (!res.ok) return []
    const json = await res.json()
    if (!json.ok || !json.data) return []
    return json.data as MarketHistoryPoint[]
  } catch (err) {
    return []
  }
}

export async function getMarketOverview(): Promise<MarketQuote[]> {
  try {
    const res = await fetch(`${API_URL}/api/market/overview`)
    if (!res.ok) return []
    const json = await res.json()
    if (!json.ok || !json.data) return []
    return json.data as MarketQuote[]
  } catch (err) {
    return []
  }
}

export async function getMarketNews(symbols: string[]): Promise<MarketNewsItem[]> {
  try {
    const joined = symbols.join(',')
    const res = await fetch(`${API_URL}/api/market/news?symbols=${encodeURIComponent(joined)}`)
    if (!res.ok) {
      return []
    }
    const json = await res.json()
    if (!json.ok || !Array.isArray(json.data) || json.data.length === 0) {
      return []
    }
    return json.data as MarketNewsItem[]
  } catch (err) {
    return []
  }
}

export const FX_FALLBACK_RATE = 16000

export interface FxRate {
  rate: number
  source: 'live' | 'fallback'
}

/** Fetch live USD/IDR exchange rate. Falls back to 16000 if unavailable. */
export async function getUsdIdrRate(): Promise<FxRate> {
  try {
    const quote = await getMarketQuote('USDIDR=X')
    if (quote && quote.price > 1000) {
      return { rate: quote.price, source: 'live' }
    }
    return { rate: FX_FALLBACK_RATE, source: 'fallback' }
  } catch {
    return { rate: FX_FALLBACK_RATE, source: 'fallback' }
  }
}
