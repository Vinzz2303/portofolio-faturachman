import React, { useState } from 'react'
import { useLanguagePreference } from '../../utils/language'

interface Props {
  onAnalyze: (input: string) => void
  loading: boolean
}

const EXAMPLES = [
  'BBCA 40%, BBRI 30%, TLKM 30%',
  'BMRI 30%, ASII 20%, ADRO 20%, ICBP 30%',
  'GOTO 50%, TLKM 50%',
]

export default function HeroInput({ onAnalyze, loading }: Props) {
  const [value, setValue] = useState('')
  const { language } = useLanguagePreference()

  const submit = () => {
    const clean = value.trim()
    if (clean) onAnalyze(clean)
  }

  return (
    <div className="w-full max-w-2xl mx-auto space-y-6">
      {/* Input Area */}
      <div className="relative group">
        <div className="absolute -inset-1 rounded-[22px] bg-gradient-to-b from-white/10 to-transparent opacity-0 group-focus-within:opacity-100 transition-opacity duration-500 pointer-events-none" />
        
        <div className="relative bg-[#0f1116] border border-white/10 rounded-3xl p-2 shadow-2xl transition-all duration-300 group-focus-within:border-white/20 group-focus-within:shadow-teal-500/5">
          <textarea
            value={value}
            onChange={e => setValue(e.target.value)}
            onKeyDown={e => { if (e.key === 'Enter' && (e.metaKey || e.ctrlKey)) submit() }}
            placeholder={language === 'id' ? 'Contoh: BBCA 40%, BBRI 30%, TLKM 30%' : 'Example: BBCA 40%, BBRI 30%, TLKM 30%'}
            rows={1}
            className="w-full bg-transparent border-none px-6 py-5 text-white placeholder:text-slate-600 font-medium text-lg resize-none focus:outline-none transition-colors leading-tight overflow-hidden"
            style={{ minHeight: '64px' }}
          />
          
          <div className="flex items-center justify-between px-2 pb-2">
            <div className="flex gap-1.5 pl-4">
              {EXAMPLES.map((ex, i) => (
                <button
                  key={i}
                  onClick={() => setValue(ex)}
                  className="text-[10px] font-mono px-2.5 py-1 rounded-lg bg-white/[0.03] border border-white/5 text-slate-500 hover:text-teal-400 hover:bg-teal-400/5 hover:border-teal-400/20 transition-all"
                >
                  {language === 'id' ? 'Opsi' : 'Option'} {i + 1}
                </button>
              ))}
            </div>

            <button
              onClick={submit}
              disabled={loading || !value.trim()}
              className="premium-button px-6 py-3 bg-white text-black font-semibold rounded-2xl disabled:opacity-20 hover:bg-teal-400 transition-all min-w-[140px] text-sm"
            >
              {loading ? (
                <span className="flex items-center gap-2 justify-center">
                  <svg className="animate-spin w-4 h-4" fill="none" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"/>
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z"/>
                  </svg>
                  {language === 'id' ? 'Proses' : 'Processing'}
                </span>
              ) : (language === 'id' ? 'Analisa Portofolio' : 'Analyze Portfolio')}
            </button>
          </div>
        </div>
      </div>

      <p className="text-[10px] font-mono text-slate-600 uppercase tracking-[0.2em]">
        {language === 'id' ? 'Tekan' : 'Press'} <kbd className="bg-white/5 px-1.5 py-0.5 rounded border border-white/10">Ctrl + Enter</kbd> {language === 'id' ? 'untuk menganalisis cepat' : 'for quick analysis'}
      </p>
    </div>
  )
}
