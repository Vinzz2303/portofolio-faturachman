import React from 'react'
import { motion } from 'framer-motion'
import { useLanguagePreference } from '../utils/language'

const highlights = [
  "AI Product Builder",
  "Retail Intelligence System",
  "React + FastAPI Developer",
  "Multi-Model AI Workflow",
  "Risk-Aware Decision Support"
]

export default function Founder() {
  const { language } = useLanguagePreference()

  return (
    <section className="py-24 relative overflow-hidden">
      <div className="container-saas">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
          >
            <div className="panel-label mb-2">Founder & AI Developer</div>
            <h2 className="text-4xl font-bold mb-6 text-gradient">Faturachman Alkahfi</h2>
            <p className="text-lg text-white/70 leading-relaxed mb-8">
              {language === 'en'
                ? "I am an AI developer focused on building intelligence systems that help people think deeper before making decisions. Through Ting AI, I am exploring how AI can support retail investors with portfolio awareness, risk clarity, and decision insight — without turning AI into a blind signal machine."
                : "Saya adalah pengembang AI yang fokus pada pembangunan sistem inteligensi yang membantu orang berpikir lebih dalam sebelum mengambil keputusan. Melalui Ting AI, saya mengeksplorasi bagaimana AI dapat mendukung investor ritel dengan kesadaran portofolio, kejelasan risiko, dan wawasan keputusan — tanpa mengubah AI menjadi mesin sinyal buta."}
            </p>
            <div className="flex flex-wrap gap-3">
              {highlights.map((item, i) => (
                <span key={item} className="px-4 py-1.5 glass-card text-xs font-mono text-accent/80 border-accent/10">
                  {item}
                </span>
              ))}
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="relative"
          >
            <div className="glass-card aspect-square max-w-md mx-auto overflow-hidden group">
              <img 
                src="/profile.png" 
                alt="Faturachman Alkahfi" 
                className="w-100 h-100 object-cover opacity-80 group-hover:scale-105 transition-transform duration-700 grayscale hover:grayscale-0"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-dark to-transparent opacity-60" />
              <div className="absolute bottom-6 left-6 right-6">
                 <div className="panel-label text-accent text-[9px] mb-1">SYSTEM_ACCESS: FOUNDER</div>
                 <div className="h-0.5 w-12 bg-accent/40" />
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  )
}
