import React from 'react'
import { motion } from 'framer-motion'
import type { Variants } from 'framer-motion'
import { useLanguagePreference } from '../utils/language'

const projects = [
  {
    title: "AI Portfolio Dashboard",
    status: "v2.1 Stable",
    insight: "High-performance interface for market data visualization.",
    stack: "React, Recharts, FastAPI",
    color: "#25d0c3"
  },
  {
    title: "OpenBB Fast Data Layer",
    status: "Production",
    insight: "Optimized abstraction for multi-source financial intelligence.",
    stack: "Python, Redis, GraphQL",
    color: "#4ea8de"
  },
  {
    title: "Portfolio Risk Copilot",
    status: "Beta",
    insight: "LLM-driven reasoning engine for portfolio concentration analysis.",
    stack: "Gemini Pro, LangChain",
    color: "#d6b15d"
  },
  {
    title: "AI Developer Website",
    status: "Active",
    insight: "This portfolio — exploring SaaS-style developer identity.",
    stack: "Tailwind, Framer Motion",
    color: "#fff"
  }
]

const container: Variants = {
  hidden: { opacity: 0 },
  show: {
    opacity: 1,
    transition: {
      staggerChildren: 0.1
    }
  }
}

const item: Variants = {
  hidden: { opacity: 0, y: 20 },
  show: { opacity: 1, y: 0, transition: { duration: 0.6, ease: [0.16, 1, 0.3, 1] } }
}

export default function Projects({ sectionId }: { sectionId: string }) {
  const { language } = useLanguagePreference()

  return (
    <section id={sectionId} className="py-24 bg-white/[0.01]">
      <div className="container-saas">
        <div className="mb-16">
          <div className="panel-label mb-2 text-accent">Recent Work</div>
          <h2 className="text-3xl font-bold text-gradient">Intelligence Modules</h2>
        </div>

        <motion.div 
          variants={container}
          initial="hidden"
          whileInView="show"
          viewport={{ once: true, margin: "-100px" }}
          className="grid md:grid-cols-2 lg:grid-cols-4 gap-6"
        >
          {projects.map((project, i) => (
            <motion.div
              key={project.title}
              variants={item}
              className="glass-card p-6 flex flex-col justify-between hover-glow transition-all will-change-transform group"
            >
              <div>
                <div className="flex justify-between items-start mb-6">
                  <div className="status-badge" style={{ color: project.color, borderColor: `${project.color}22`, background: `${project.color}08` }}>
                    {project.status}
                  </div>
                </div>
                <h3 className="text-xl font-bold mb-3 group-hover:text-accent transition-colors">{project.title}</h3>
                <p className="text-sm text-white/50 leading-relaxed mb-6">{project.insight}</p>
              </div>
              
              <div className="pt-5 border-t border-white/5">
                <div className="panel-label text-[9px] mb-2 opacity-50">Stack</div>
                <div className="text-[10px] font-mono text-white/40 tracking-wider uppercase">{project.stack}</div>
              </div>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  )
}
