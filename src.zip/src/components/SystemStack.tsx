import React from 'react'
import { motion } from 'framer-motion'

const stacks = [
  {
    title: "Interface Layer",
    techs: ["React", "Tailwind", "Framer Motion"],
    desc: "Interactive AI dashboard experience with smooth, responsive intelligence panels.",
    color: "#25d0c3"
  },
  {
    title: "API Layer",
    techs: ["FastAPI", "Python"],
    desc: "Backend layer for processing requests, routing data, and connecting intelligence services.",
    color: "#4ea8de"
  },
  {
    title: "AI Reasoning Layer",
    techs: ["Gemini", "GPT", "Groq"],
    desc: "Multi-model workflow for generating risk-aware insight and decision support.",
    color: "#d6b15d"
  },
  {
    title: "Data Layer",
    techs: ["Polygon", "FRED", "Market Data"],
    desc: "Market and macro data sources used to strengthen portfolio analysis.",
    color: "#fff"
  }
]

export default function SystemStack() {
  return (
    <section className="py-24 relative overflow-hidden">
      <div className="container-saas">
        <div className="mb-16 text-center lg:text-left">
          <div className="panel-label mb-2 text-accent">Architecture</div>
          <h2 className="text-3xl md:text-4xl font-bold text-gradient">System Stack Architecture</h2>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 relative">
          {/* Subtle Connection Line (Desktop) */}
          <div className="hidden lg:block absolute top-1/2 left-0 w-full h-px bg-gradient-to-r from-transparent via-white/10 to-transparent -translate-y-1/2 z-0" />

          {stacks.map((stack, i) => (
            <motion.div
              key={stack.title}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1 }}
              className="glass-card p-8 flex flex-col justify-between hover-glow transition-all will-change-transform group relative z-10 h-full"
            >
              <div>
                <div className="flex justify-between items-start mb-6">
                   <div className="w-10 h-10 rounded-lg flex items-center justify-center bg-white/[0.03] border border-white/5 group-hover:border-accent/30 transition-colors">
                      <span className="text-xs font-mono text-white/20">0{i+1}</span>
                   </div>
                </div>
                
                <h3 className="text-xl font-bold mb-4 group-hover:text-accent transition-colors">{stack.title}</h3>
                <p className="text-sm text-white/50 leading-relaxed mb-8">{stack.desc}</p>
              </div>

              <div className="space-y-4">
                <div className="panel-label text-[9px] opacity-40">Core Technology</div>
                <div className="flex flex-wrap gap-2">
                  {stack.techs.map(tech => (
                    <span key={tech} className="px-2 py-1 text-[10px] font-mono bg-white/[0.03] border border-white/5 rounded text-white/60">
                      {tech}
                    </span>
                  ))}
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Visual Flow Indicator */}
        <div className="mt-12 flex items-center justify-center gap-2 text-[10px] font-mono text-white/20 uppercase tracking-widest">
           <span>Interface</span>
           <span className="w-4 h-px bg-white/10" />
           <span>API</span>
           <span className="w-4 h-px bg-white/10" />
           <span>AI Reasoning</span>
           <span className="w-4 h-px bg-white/10" />
           <span>Data</span>
           <span className="w-4 h-px bg-white/10" />
           <span className="text-accent/60">Insight Output</span>
        </div>
      </div>
    </section>
  )
}
