import React, { useEffect, useState, useCallback, useMemo } from 'react'
import { fetchStock, type DetailedStockData } from '../lib/stockService'
import AiChat from '../components/AiChat'
import { formatCurrency as formatDisplayCurrency } from '../utils/currency'
import { getPortfolioIntelligence } from '../utils/portfolioIntelligence'
import { generatePortfolioInsight, generateRiskSimulation } from '../utils/portfolioInsightHero'
import { useLanguagePreference } from '../utils/language'
import '../premium-dashboard.css'
import UpgradeSection from '../components/UpgradeSection'
import { InsightWithTriggers } from '../components/InsightUpgradeTrigger'
import { getUsdIdrRate, FX_FALLBACK_RATE } from '../services/marketData'
import type { FxRate } from '../services/marketData'



export type V2Position = {
  id: string
  symbol: string        // display symbol: XAU, BBCA.JK, BTC
  marketSymbol?: string // Yahoo Finance API symbol: GC=F, BBCA.JK, BTC-USD
  assetCurrency?: 'IDR' | 'USD' // the currency this asset trades in
  assetType: "stock" | "commodity" | "crypto"
  region: "ID" | "GLOBAL"
  quantity: number
  entryPrice: number
  entryCurrency: "IDR" | "USD"
  createdAt: string
}

type FormState = {
  symbol: string
  assetType: "stock" | "commodity" | "crypto"
  region: "ID" | "GLOBAL"
  quantity: string
  entryPrice: string
  entryCurrency: "IDR" | "USD"
}

const initialForm: FormState = {
  symbol: '',
  assetType: 'stock',
  region: 'ID',
  quantity: '',
  entryPrice: '',
  entryCurrency: 'IDR'
}

const LOCAL_STORAGE_KEY = "tingai_portfolio_positions_v2"

const DEFAULT_POSITIONS: V2Position[] = [
  { id: 'pos-init-1', symbol: 'XAU', marketSymbol: 'GC=F', assetCurrency: 'USD', assetType: 'commodity', region: 'GLOBAL', quantity: 2.5, entryPrice: 38234399, entryCurrency: 'IDR', createdAt: new Date().toISOString() },
  { id: 'pos-init-2', symbol: 'BTC', marketSymbol: 'BTC-USD', assetCurrency: 'USD', assetType: 'crypto', region: 'GLOBAL', quantity: 0.08, entryPrice: 96500, entryCurrency: 'USD', createdAt: new Date().toISOString() },
  { id: 'pos-init-3', symbol: 'BBCA.JK', assetCurrency: 'IDR', assetType: 'stock', region: 'ID', quantity: 5000, entryPrice: 8500, entryCurrency: 'IDR', createdAt: new Date().toISOString() },
  { id: 'pos-init-4', symbol: 'BMRI.JK', assetCurrency: 'IDR', assetType: 'stock', region: 'ID', quantity: 10000, entryPrice: 6000, entryCurrency: 'IDR', createdAt: new Date().toISOString() }
]

const safeUUID = () => {
  if (typeof crypto !== 'undefined' && crypto.randomUUID) {
    return crypto.randomUUID()
  }
  return `pos-${Date.now()}-${Math.random().toString(36).slice(2)}`
}

const isValidPosition = (item: any): item is V2Position => {
  if (!item || typeof item !== 'object') return false
  if (typeof item.id !== 'string' || !item.id) return false
  if (typeof item.symbol !== 'string' || !item.symbol) return false
  if (!['stock', 'commodity', 'crypto'].includes(item.assetType)) return false
  if (!['ID', 'GLOBAL'].includes(item.region)) return false
  if (typeof item.quantity !== 'number' || !Number.isFinite(item.quantity) || item.quantity <= 0) return false
  if (typeof item.entryPrice !== 'number' || !Number.isFinite(item.entryPrice) || item.entryPrice <= 0) return false
  if (!['IDR', 'USD'].includes(item.entryCurrency)) return false
  if (typeof item.createdAt !== 'string' || !item.createdAt) return false
  return true
}

const loadPositions = (): V2Position[] => {
  const saved = localStorage.getItem(LOCAL_STORAGE_KEY)
  if (saved === null) return DEFAULT_POSITIONS
  
  try {
    const parsed = JSON.parse(saved)
    if (!Array.isArray(parsed)) return DEFAULT_POSITIONS
    if (parsed.length === 0) return []
    
    const validItems = parsed.filter(isValidPosition)
    if (parsed.length > 0 && validItems.length === 0) return DEFAULT_POSITIONS
    
    // Migrate any bad symbols (XAU.JK → XAU/GC=F) — idempotent
    return migratePositions(validItems)
  } catch {
    return DEFAULT_POSITIONS
  }
}

// ── Symbol resolution ────────────────────────────────────────────────────────

/**
 * Maps known commodity/crypto display symbols → Yahoo Finance market symbols.
 * This is the canonical truth for non-stock assets.
 */
const CANONICAL_SYMBOLS: Record<string, { display: string; market: string; assetCurrency: 'IDR' | 'USD' }> = {
  // Gold
  'XAU':     { display: 'XAU',  market: 'GC=F',    assetCurrency: 'USD' },
  'GOLD':    { display: 'XAU',  market: 'GC=F',    assetCurrency: 'USD' },
  'GC=F':    { display: 'XAU',  market: 'GC=F',    assetCurrency: 'USD' },
  'XAUUSD':  { display: 'XAU',  market: 'GC=F',    assetCurrency: 'USD' },
  // Bitcoin
  'BTC':     { display: 'BTC',  market: 'BTC-USD', assetCurrency: 'USD' },
  'BITCOIN': { display: 'BTC',  market: 'BTC-USD', assetCurrency: 'USD' },
  'BTC-USD': { display: 'BTC',  market: 'BTC-USD', assetCurrency: 'USD' },
  // Ethereum
  'ETH':     { display: 'ETH',  market: 'ETH-USD', assetCurrency: 'USD' },
  'ETH-USD': { display: 'ETH',  market: 'ETH-USD', assetCurrency: 'USD' },
  // Oil
  'OIL':     { display: 'OIL',  market: 'CL=F',   assetCurrency: 'USD' },
  'CL=F':    { display: 'OIL',  market: 'CL=F',   assetCurrency: 'USD' },
  // Silver
  'XAG':     { display: 'XAG',  market: 'SI=F',   assetCurrency: 'USD' },
  'SILVER':  { display: 'XAG',  market: 'SI=F',   assetCurrency: 'USD' },
}

/**
 * Infer the trading currency of an asset from its type and region.
 */
function inferAssetCurrency(assetType: string, region: string): 'IDR' | 'USD' {
  if (assetType === 'stock' && region === 'ID') return 'IDR'
  return 'USD' // crypto, commodity, global stock
}

/**
 * Resolve a raw user input symbol into { display, market, assetCurrency }.
 * - stock + region ID: BBCA → { display: BBCA.JK, market: BBCA.JK, assetCurrency: IDR }
 * - commodity/crypto: XAU → { display: XAU, market: GC=F, assetCurrency: USD }
 */
function resolveSymbol(
  rawSymbol: string,
  assetType: string,
  region: string
): { display: string; market: string; assetCurrency: 'IDR' | 'USD' } {
  const upper = rawSymbol.trim().toUpperCase()

  // Check canonical map first (commodity/crypto)
  if (CANONICAL_SYMBOLS[upper]) {
    return CANONICAL_SYMBOLS[upper]
  }

  // For stocks in Indonesia, append .JK if missing
  if (assetType === 'stock' && region === 'ID') {
    const display = upper.endsWith('.JK') ? upper : `${upper}.JK`
    return { display, market: display, assetCurrency: 'IDR' }
  }

  // Otherwise keep as-is (global stock, SPY, QQQ, etc.) — USD
  return { display: upper, market: upper, assetCurrency: 'USD' }
}

/**
 * One-time migration: fix bad symbols AND infer missing assetCurrency.
 */
function migratePositions(positions: V2Position[]): V2Position[] {
  return positions.map(pos => {
    const upper = pos.symbol.toUpperCase()

    // Commodity/crypto that accidentally got .JK suffix
    const withoutJK = upper.endsWith('.JK') ? upper.slice(0, -3) : upper
    if (pos.assetType !== 'stock' && CANONICAL_SYMBOLS[withoutJK]) {
      const canonical = CANONICAL_SYMBOLS[withoutJK]
      return {
        ...pos,
        symbol: canonical.display,
        marketSymbol: canonical.market,
        assetCurrency: canonical.assetCurrency,
        region: 'GLOBAL' as const
      }
    }

    // Commodity/crypto without suffix but missing marketSymbol or assetCurrency
    if (pos.assetType !== 'stock' && CANONICAL_SYMBOLS[upper]) {
      const canonical = CANONICAL_SYMBOLS[upper]
      return {
        ...pos,
        symbol: canonical.display,
        marketSymbol: canonical.market,
        assetCurrency: canonical.assetCurrency
      }
    }

    // Infer assetCurrency if not set
    if (!pos.assetCurrency) {
      return { ...pos, assetCurrency: inferAssetCurrency(pos.assetType, pos.region) }
    }

    return pos
  })
}

const isSafeNumber = (val: any): val is number => {
  return typeof val === 'number' && Number.isFinite(val) && !Number.isNaN(val)
}

const safeDisplayCurrency = (value: number | null | undefined, currency: string) => {
  if (!isSafeNumber(value)) return '—'
  return formatDisplayCurrency(value, currency)
}

const formatSafeSigned = (value: number | null | undefined, fractionDigits = 2) => {
  if (!isSafeNumber(value)) return '—'
  const prefix = value > 0 ? '+' : ''
  return `${prefix}${new Intl.NumberFormat('id-ID', {
    minimumFractionDigits: fractionDigits,
    maximumFractionDigits: fractionDigits
  }).format(value)}`
}

const formatSafePercent = (value: number | null | undefined, fractionDigits = 2) => {
  if (!isSafeNumber(value)) return '—'
  return `${new Intl.NumberFormat('id-ID', {
    minimumFractionDigits: fractionDigits,
    maximumFractionDigits: fractionDigits
  }).format(value)}%`
}

const formatFreshness = (value?: string | null, language: string = 'id') => {
  if (!value) return language === 'en' ? 'Waiting for update...' : 'Menunggu pembaruan...'
  const timestamp = new Date(value).getTime()
  if (Number.isNaN(timestamp)) return language === 'en' ? 'Invalid time format' : 'Format waktu tidak valid'
  const diffMs = Date.now() - timestamp
  if (diffMs < 60 * 1000) return language === 'en' ? 'Just updated' : 'Baru saja diperbarui'
  const diffMinutes = Math.floor(diffMs / (60 * 1000))
  if (diffMinutes < 60) return language === 'en' ? `Updated ${diffMinutes}m ago` : `Diperbarui ${diffMinutes}m lalu`
  const diffHours = Math.floor(diffMinutes / 60)
  if (diffHours < 24) return language === 'en' ? `Updated ${diffHours}h ago` : `Diperbarui ${diffHours}j lalu`
  const diffDays = Math.floor(diffHours / 24)
  return language === 'en' ? `Updated ${diffDays} days ago` : `Diperbarui ${diffDays} hari lalu`
}

const normalizeNumericInput = (value: string) => {
  const trimmed = value.trim()
  if (!trimmed) return ''
  if (/^\d{1,3}(\.\d{3})+$/.test(trimmed)) {
    return trimmed.replace(/\./g, '')
  }
  return trimmed.replace(/,/g, '')
}

const getStatusBadge = (status: string, language: string = 'id') => {
  switch(status) {
    case 'delayed': return <span className="bg-yellow-500/10 text-yellow-400 border border-yellow-500/20 px-2 py-0.5 rounded text-[10px] uppercase font-bold tracking-wider">{language === 'en' ? 'Delayed' : 'Tertunda'}</span>;
    case 'fallback': return <span className="bg-amber-500/10 text-amber-400 border border-amber-500/20 px-2 py-0.5 rounded text-[10px] uppercase font-bold tracking-wider">{language === 'en' ? 'Estimate' : 'Estimasi'}</span>;
    case 'error': return <span className="bg-red-500/10 text-red-400 border border-red-500/20 px-2 py-0.5 rounded text-[10px] uppercase font-bold tracking-wider">{language === 'en' ? 'Unavailable' : 'Tidak tersedia'}</span>;
    default: return null;
  }
}

// ── Pro Gate Component ────────────────────────────────────────────────────────
function ProGate({ children, title, userPlan }: { children: React.ReactNode; title: string; userPlan?: string }) {
  const [revealed, setRevealed] = useState(false)
  const { language } = useLanguagePreference()
  const isPremium = userPlan && userPlan !== 'free'
  
  if (revealed || isPremium) return <>{children}</>
  return (
    <div className="relative rounded-2xl border border-white/[0.07] overflow-hidden">
      <div className="pointer-events-none blur-[2px] opacity-40 select-none">
        {children}
      </div>
      <div className="absolute inset-0 flex flex-col items-center justify-center bg-[#0b0d12]/70 backdrop-blur-sm rounded-2xl px-6 text-center">
        <p className="text-xs font-mono text-slate-400 uppercase tracking-widest mb-3">{language === 'id' ? 'Analisis Mendalam' : 'Deep Analysis'}</p>
        <p className="text-slate-300 text-sm font-medium mb-1">{title}</p>
        <p className="text-slate-500 text-xs mb-5 max-w-xs leading-relaxed">{language === 'id' ? 'Tersedia di Ting AI Pro — akses lebih dalam tanpa perlu membayar lebih saat ini.' : 'Available in Ting AI Pro — deeper access without paying more right now.'}</p>
        <button
          onClick={() => setRevealed(true)}
          className="px-5 py-2 text-xs font-semibold rounded-xl border border-teal-500/40 text-teal-400 hover:bg-teal-500/10 transition-all"
        >
          {language === 'id' ? 'Lihat penjelasan lengkap' : 'View full explanation'}
        </button>
      </div>
    </div>
  )
}

export default function Portfolio() {
  const { language } = useLanguagePreference()
  // Derive plan from localStorage session (set by auth) — default free
  const userPlan = useMemo(() => {
    try {
      return localStorage.getItem('lifeOS_user_plan') || 'free'
    } catch { return 'free' }
  }, [])

  // ── Base Currency (separate from UI language) ─────────────────────────────
  const BASE_CURRENCY_KEY = 'tingai_portfolio_base_currency'
  const [baseCurrency, setBaseCurrencyState] = useState<'IDR' | 'USD'>(() => {
    try {
      const saved = localStorage.getItem(BASE_CURRENCY_KEY)
      return (saved === 'USD' || saved === 'IDR') ? saved : 'IDR'
    } catch { return 'IDR' }
  })
  const setBaseCurrency = (c: 'IDR' | 'USD') => {
    try { localStorage.setItem(BASE_CURRENCY_KEY, c) } catch {}
    setBaseCurrencyState(c)
  }

  // ── FX Rate (USD/IDR) ─────────────────────────────────────────────────────
  const [fxRate, setFxRate] = useState<FxRate>({ rate: FX_FALLBACK_RATE, source: 'fallback' })

  useEffect(() => {
    getUsdIdrRate().then(setFxRate)
  }, [])

  /** Convert a value from its asset currency to baseCurrency */
  const toBase = useCallback((value: number, assetCurrency: 'IDR' | 'USD'): number => {
    if (assetCurrency === baseCurrency) return value
    if (assetCurrency === 'USD' && baseCurrency === 'IDR') return value * fxRate.rate
    if (assetCurrency === 'IDR' && baseCurrency === 'USD') return value / fxRate.rate
    return value
  }, [baseCurrency, fxRate.rate])

  // Alias — keeps all existing JSX references working after baseCurrency replaced displayCurrency
  const displayCurrency = baseCurrency


  const [positions, setPositions] = useState<V2Position[]>(loadPositions)

  useEffect(() => {
    localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(positions))
  }, [positions])

  const [form, setForm] = useState<FormState>(initialForm)
  const [editingHoldingId, setEditingHoldingId] = useState<string | null>(null)
  const [refreshing, setRefreshing] = useState(false)
  const [error, setError] = useState('')
  const [success, setSuccess] = useState('')
  const [livePrices, setLivePrices] = useState<Record<string, DetailedStockData>>({})
  // Track whether the first market data fetch has completed
  const [marketDataReady, setMarketDataReady] = useState(false)

  const syncLivePrices = useCallback(async () => {
    try {
      // Use marketSymbol (e.g. GC=F) when available, otherwise display symbol
      const toFetch = Array.from(new Set(
        positions.map(p => p.marketSymbol || p.symbol)
      ))
      if (toFetch.length === 0) return

      const results = await Promise.allSettled(toFetch.map(sym => fetchStock(sym)))

      const priceMap: Record<string, DetailedStockData> = {}
      results.forEach((r, i) => {
        if (r.status === 'fulfilled') {
          const d = r.value
          const fetchedAs = toFetch[i]
          // Map by the marketSymbol key used to fetch (e.g. 'GC=F')
          priceMap[fetchedAs] = d
          // Also map by yahooSymbol and display symbol returned
          priceMap[d.yahooSymbol] = d
          priceMap[d.symbol] = d
          // Map by ALL position display symbols that use this market symbol
          positions.forEach(p => {
            if ((p.marketSymbol || p.symbol) === fetchedAs) {
              priceMap[p.symbol] = d
            }
          })
        }
      })

      setLivePrices(prev => ({...prev, ...priceMap}))
    } catch {
    } finally {
      setMarketDataReady(true)
    }
  }, [positions])

  useEffect(() => {
    void syncLivePrices()
    const interval = setInterval(syncLivePrices, 30000)
    return () => clearInterval(interval)
  }, [syncLivePrices])

  const handleRefreshPrices = async () => {
    setRefreshing(true)
    await syncLivePrices()
    setSuccess('Data diperbarui.')
    setTimeout(() => setSuccess(''), 3000)
    setRefreshing(false)
  }

  const enrichedHoldings = useMemo(() => {
    return positions.map(pos => {
      // Look up by display symbol first, then by marketSymbol (e.g. GC=F for XAU)
      const live =
        livePrices[pos.symbol] ||
        livePrices[pos.marketSymbol ?? ''] ||
        livePrices[`${pos.symbol}.JK`]
      const status = live?.status || 'fallback'

      // Determine asset's trading currency (with migration fallback)
      const assetCurrency: 'IDR' | 'USD' =
        pos.assetCurrency ?? inferAssetCurrency(pos.assetType, pos.region)

      // Native price in the asset's own currency
      const nativePrice = status === 'error' ? 0 : (live?.price || pos.entryPrice)
      const nativeValue  = pos.quantity * nativePrice
      const nativeInvested = pos.quantity * pos.entryPrice
      const nativePnl   = status === 'error' ? 0 : nativeValue - nativeInvested
      const pnlPct      = nativeInvested > 0 ? (nativePnl / nativeInvested) * 100 : 0

      // Converted to base currency
      const valueInBase    = toBase(nativeValue, assetCurrency)
      const investedInBase = toBase(nativeInvested, assetCurrency)
      const pnlInBase      = status === 'error' ? 0 : (valueInBase - investedInBase)

      return {
        id: pos.id,
        assetId: pos.id,
        symbol: pos.symbol,
        name: pos.symbol,
        assetType: pos.assetType,
        region: pos.region,
        assetCurrency,
        quantity: pos.quantity,
        entryPrice: pos.entryPrice,
        entryCurrency: pos.entryCurrency,
        // Native values (for display in asset's own currency)
        latestPrice: nativePrice,
        nativeValue,
        nativeInvested,
        nativePnl,
        // Base-currency values (for portfolio math)
        currentValue:  valueInBase,   // ← this feeds portfolioIntelligence
        investedAmount:  investedInBase,
        investedAmountDisplay: investedInBase,
        pnl:  pnlInBase,
        pnlPct,
        quoteCurrency: assetCurrency,
        displayCurrency: baseCurrency,
        status,
        fetchedAt: live?.fetchedAt
      }
    })
  }, [positions, livePrices, toBase, baseCurrency])

  const enrichedSummary = useMemo(() => {
    const validHoldings = enrichedHoldings.filter(h => h.status !== 'error')
    const totalCurrentValue = validHoldings.reduce((sum, h) => sum + h.currentValue, 0)
    const totalInvested     = validHoldings.reduce((sum, h) => sum + h.investedAmount, 0)
    const totalPnl          = totalCurrentValue - totalInvested
    const totalPnlPct       = totalInvested > 0 ? (totalPnl / totalInvested) * 100 : 0

    return {
      totalCurrentValue,
      totalInvested,
      totalPnl,
      totalPnlPct,
      totalHoldings: validHoldings.length,
      displayCurrency: baseCurrency // used by portfolioIntelligence
    }
  }, [enrichedHoldings, baseCurrency])

  const normalizedPortfolio = useMemo(() => ({
    summary: enrichedSummary,
    holdings: enrichedHoldings
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  }) as any, [enrichedSummary, enrichedHoldings])

  const intelligence = useMemo(
    () => getPortfolioIntelligence(normalizedPortfolio as any, language),
    [language, normalizedPortfolio]
  )
  const portfolioHeroInsight = useMemo(
    () => generatePortfolioInsight(intelligence, intelligence.portfolioTone, language),
    [intelligence, language]
  )
  const riskSimulation = useMemo(
    () => generateRiskSimulation(intelligence, language),
    [intelligence, language]
  )

  const latestFetch = useMemo(() => {
    return Object.values(livePrices).reduce((latest, current) => {
      if (!current.fetchedAt) return latest;
      if (!latest) return current.fetchedAt;
      return new Date(current.fetchedAt) > new Date(latest) ? current.fetchedAt : latest;
    }, null as string | null);
  }, [livePrices]);

  useEffect(() => {
    window.scrollTo({ top: 0, left: 0, behavior: 'auto' })
  }, [])

  const handleStartEdit = (holding: any) => {
    setEditingHoldingId(holding.id)
    setForm({
      symbol: holding.symbol,
      assetType: holding.assetType,
      region: holding.region,
      quantity: String(holding.quantity),
      entryPrice: String(holding.entryPrice),
      entryCurrency: holding.entryCurrency
    })
    setError('')
    setSuccess('')
    document.getElementById('portfolio-form-section')?.scrollIntoView({ behavior: 'smooth' })
  }

  const handleCancelEdit = () => {
    setEditingHoldingId(null)
    setForm(initialForm)
    setError('')
  }

  const handleDeleteHolding = (holdingId: string) => {
    if (!window.confirm('Hapus posisi ini?')) return
    setPositions(prev => prev.filter(p => p.id !== holdingId))
    if (editingHoldingId === holdingId) handleCancelEdit()
    setSuccess('Posisi berhasil dihapus.')
    setTimeout(() => setSuccess(''), 3000)
  }

  const restoreDefaultPositions = () => {
    if (window.confirm('Muat portofolio bawaan?')) {
      setPositions(DEFAULT_POSITIONS)
      setSuccess('Portofolio bawaan berhasil dimuat.')
      setTimeout(() => setSuccess(''), 3000)
    }
  }

  const handleSubmit = (event: React.FormEvent) => {
    event.preventDefault()
    setError('')
    setSuccess('')

    try {
      if (!form.assetType || !['stock', 'commodity', 'crypto'].includes(form.assetType))
        throw new Error('Kategori aset tidak valid.')
      if (!form.region || !['ID', 'GLOBAL'].includes(form.region))
        throw new Error('Wilayah tidak valid.')
      if (!form.entryCurrency || !['IDR', 'USD'].includes(form.entryCurrency))
        throw new Error('Mata uang tidak valid.')

      const normRegion = form.region as 'ID' | 'GLOBAL'
      const resolved = resolveSymbol(form.symbol, form.assetType, normRegion)
      if (!resolved.display) throw new Error('Simbol aset tidak boleh kosong.')

      const qty = Number(normalizeNumericInput(form.quantity))
      if (!Number.isFinite(qty) || qty <= 0) throw new Error('Kuantitas harus berupa angka lebih besar dari 0.')

      const price = Number(normalizeNumericInput(form.entryPrice))
      if (!Number.isFinite(price) || price <= 0) throw new Error('Harga rata-rata (entry) harus lebih besar dari 0.')

      const isDuplicate = positions.some(p => p.symbol === resolved.display && p.id !== editingHoldingId)
      if (isDuplicate) {
        throw new Error('Aset ini sudah ada di portofolio. Gunakan edit untuk mengubah posisinya.')
      }

      // For commodity/crypto, always force region GLOBAL
      const finalRegion: 'ID' | 'GLOBAL' =
        form.assetType !== 'stock' ? 'GLOBAL' : normRegion

      const newPosition: V2Position = {
        id: editingHoldingId || safeUUID(),
        symbol: resolved.display,
        marketSymbol: resolved.market !== resolved.display ? resolved.market : undefined,
        assetCurrency: resolved.assetCurrency,
        assetType: form.assetType as any,
        region: finalRegion,
        quantity: qty,
        entryPrice: price,
        entryCurrency: form.entryCurrency as any,
        createdAt: new Date().toISOString()
      }

      if (editingHoldingId) {
        setPositions(prev => prev.map(p => p.id === editingHoldingId ? newPosition : p))
        setSuccess('Perubahan posisi berhasil disimpan.')
      } else {
        setPositions(prev => [...prev, newPosition])
        setSuccess('Posisi baru berhasil ditambahkan.')
      }
      
      handleCancelEdit()
      setTimeout(() => setSuccess(''), 3000)
    } catch (err: any) {
      setError(err.message || 'Terjadi kesalahan input.')
    }
  }

  return (
    <div className="min-h-screen bg-[#0b0d12] text-white selection:bg-teal-500/30 pb-20">
      <div className="max-w-6xl mx-auto px-6 pt-32 pb-6 flex justify-between items-center relative z-10">
        <div className="space-y-1">
          <h1 className="text-xl font-medium tracking-tight">
            {language === 'id' ? 'Ruang Portofolio' : 'Personal Workspace'}
          </h1>
          <p className="text-[10px] font-mono text-slate-500 uppercase tracking-widest">{formatFreshness(latestFetch, language)}</p>
        </div>
        <div className="flex items-center gap-3">
          {/* Base Currency Toggle — independent of language */}
          <div className="flex items-center bg-white/[0.04] border border-white/10 rounded-xl overflow-hidden text-[11px] font-semibold">
            <span className="px-3 py-2 text-slate-500 font-mono">Base:</span>
            <button
              id="base-currency-idr"
              onClick={() => setBaseCurrency('IDR')}
              className={`px-3 py-2 transition-all ${
                baseCurrency === 'IDR'
                  ? 'bg-teal-500/20 text-teal-300'
                  : 'text-slate-500 hover:text-slate-300'
              }`}
            >IDR</button>
            <button
              id="base-currency-usd"
              onClick={() => setBaseCurrency('USD')}
              className={`px-3 py-2 transition-all ${
                baseCurrency === 'USD'
                  ? 'bg-teal-500/20 text-teal-300'
                  : 'text-slate-500 hover:text-slate-300'
              }`}
            >USD</button>
          </div>
          <button className="premium-button px-5 py-2.5 bg-white/[0.03] border border-white/10 hover:bg-white/10 rounded-xl text-xs font-semibold transition-all" onClick={handleRefreshPrices} disabled={refreshing}>
            {refreshing 
              ? (language === 'id' ? 'Memperbarui...' : 'Refreshing...') 
              : (language === 'id' ? 'Perbarui Pasar' : 'Refresh Market')}
          </button>
        </div>
      </div>

      <div className="max-w-6xl mx-auto px-6">
        {error && <div className="p-4 bg-red-500/10 border border-red-500/20 text-red-400 rounded-xl mb-8 text-sm">{error}</div>}
        {success && <div className="p-4 bg-teal-500/10 border border-teal-500/20 text-teal-400 rounded-xl mb-8 text-sm">{success}</div>}
      </div>

      <main className="max-w-6xl mx-auto px-6 pt-8 space-y-24 md:space-y-32">
        {/* FX Rate info bar */}
        {(
          <div className="flex items-center gap-2 text-[10px] font-mono text-slate-600 py-1">
            <span>{language === 'en' ? 'USD/IDR Rate' : 'Kurs USD/IDR'}: Rp{fxRate.rate.toLocaleString('id-ID')}</span>
            {fxRate.source === 'fallback' && (
              <span className="text-amber-600/70">• fallback</span>
            )}
          </div>
        )}

        {/* Global Data Banner — only shown after first fetch attempt completes */}
        {(() => {
          if (!marketDataReady || enrichedHoldings.length === 0) return null;
          const errorCount  = enrichedHoldings.filter(h => h.status === 'error').length;
          const totalCount  = enrichedHoldings.length;
          const allError    = errorCount === totalCount;
          const someError   = errorCount > 0 && !allError;
          const allFallback = enrichedHoldings.every(h => h.status === 'fallback');
          const allDelayed  = enrichedHoldings.every(h => h.status === 'delayed');

          // Only show red when every single holding failed — genuine outage
          if (allError) {
            return (
              <div className="bg-red-500/10 border border-red-500/20 text-red-400 p-4 rounded-xl text-sm flex items-center gap-3">
                <p>{language === 'en'
                  ? 'Market data is currently unavailable. Showing entry prices as reference.'
                  : 'Data pasar tidak tersedia saat ini. Harga entry ditampilkan sebagai referensi.'}
                </p>
              </div>
            );
          }
          // Soft amber when only some fail
          if (someError) {
            return (
              <div className="bg-amber-500/10 border border-amber-500/20 text-amber-400 p-4 rounded-xl text-sm flex items-center gap-3">
                <p>{language === 'en'
                  ? `${errorCount} of ${totalCount} assets could not load market data. Other data may be delayed.`
                  : `${errorCount} dari ${totalCount} aset tidak dapat memuat data pasar. Data lain mungkin tertunda.`}
                </p>
              </div>
            );
          }
          if (allFallback) {
            return (
              <div className="bg-amber-500/10 border border-amber-500/20 text-amber-400 p-4 rounded-xl text-sm flex items-center gap-3">
                <p>{language === 'en'
                  ? 'Market data is loading. Showing entry prices as estimates.'
                  : 'Data pasar sedang dimuat. Harga entry ditampilkan sementara.'}
                </p>
              </div>
            );
          }
          if (allDelayed) {
            return (
              <div className="bg-yellow-500/10 border border-yellow-500/20 text-yellow-400 p-4 rounded-xl text-sm flex items-center gap-3">
                <p>{language === 'en' ? 'Market data may be delayed.' : 'Data pasar mungkin mengalami keterlambatan.'}</p>
              </div>
            );
          }
          return null;
        })()}

        <section className="space-y-12 animate-in fade-in duration-700">
          <div className="flex flex-col md:flex-row md:items-start justify-between gap-6">
            <div className="space-y-5 max-w-2xl">
              <span className="label-uppercase">{language === 'id' ? 'Ringkasan Portofolio' : 'Portfolio Summary'}</span>
              <div className="space-y-4">
                <h2 className="main-insight-text">
                  {portfolioHeroInsight?.headline || (language === 'id' ? 'Menganalisis komposisi portofolio Anda...' : 'Analyzing your portfolio composition...')}
                </h2>
                {portfolioHeroInsight && (
                  <div className="space-y-2">
                    <InsightWithTriggers
                      insightText={[
                        ...portfolioHeroInsight.reasons,
                        portfolioHeroInsight.action || ''
                      ].filter(Boolean).join(' ')}
                      userPlan={userPlan}
                    />
                  </div>
                )}
              </div>
            </div>
            <div className="flex items-center gap-3 mt-2 md:mt-0">
              <span className={`px-4 py-1.5 rounded-full text-[10px] font-bold uppercase tracking-widest border ${
                portfolioHeroInsight?.risk_level === 'high' ? 'bg-red-500/10 text-red-400 border-red-500/20' :
                portfolioHeroInsight?.risk_level === 'medium' ? 'bg-orange-500/10 text-orange-400 border-orange-500/20' :
                'bg-teal-500/10 text-teal-400 border-teal-500/20'
              }`}>
                {language === 'id' ? 'Risiko' : 'Risk'} {portfolioHeroInsight?.risk_level 
                  ? (language === 'id' 
                      ? (portfolioHeroInsight.risk_level === 'high' ? 'Tinggi' : portfolioHeroInsight.risk_level === 'medium' ? 'Menengah' : 'Rendah')
                      : portfolioHeroInsight.risk_level)
                  : (language === 'id' ? 'menghitung' : 'calculating')}
              </span>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            <div className="premium-card bg-white/[0.02]">
              <span className="label-uppercase opacity-50">{language === 'id' ? 'Nilai Total' : 'Total Value'}</span>
              <div className="text-xl font-semibold numeric-value mt-3">
                {safeDisplayCurrency(enrichedSummary?.totalCurrentValue, baseCurrency)}
              </div>
            </div>
            <div className="premium-card bg-white/[0.02]">
              <span className="label-uppercase opacity-50">{language === 'id' ? 'Total Modal' : 'Total Invested'}</span>
              <div className="text-xl font-semibold numeric-value mt-3">
                {safeDisplayCurrency(enrichedSummary?.totalInvested, baseCurrency)}
              </div>
            </div>
            <div className="premium-card bg-white/[0.02]">
              <span className="label-uppercase opacity-50">{language === 'id' ? 'Imbal Hasil %' : 'Yield %'}</span>
              <div className={`text-xl font-semibold numeric-value mt-3 ${enrichedSummary?.totalPnlPct && enrichedSummary.totalPnlPct >= 0 ? 'text-teal-400' : 'text-red-400'}`}>
                {formatSafePercent(enrichedSummary?.totalPnlPct, 1)}
              </div>
            </div>
            <div className="premium-card bg-white/[0.02]">
              <span className="label-uppercase opacity-50">{language === 'id' ? 'Holding Terbesar' : 'Largest Holding'}</span>
              <div className="text-lg font-semibold tracking-tight mt-3">
                {intelligence.largestPosition ? (
                  `${intelligence.largestPosition.label} / ${formatSafePercent(intelligence.largestPosition.weight, 1)}`
                ) : (
                  <span className="text-sm font-normal text-slate-500 leading-snug block">
                    {language === 'id' ? 'Belum cukup data untuk menentukan aset paling dominan.' : 'Not enough data to determine the most influential asset.'}
                  </span>
                )}
              </div>
            </div>
          </div>
        </section>

        {enrichedHoldings.length > 0 && (
          <section className="space-y-10 animate-in fade-in duration-1000">
            <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
              <div className="space-y-2">
              <span className="label-uppercase">{language === 'id' ? 'Simulasi Risiko' : 'Risk Simulation'}</span>
                <h3 className="text-2xl font-medium tracking-tight">{language === 'id' ? 'Dampak Skenario Pasar' : 'Market Scenario Impact'}</h3>
              </div>
            </div>

            {/* FREE: single -5% scenario */}
            <div className="premium-card p-0 overflow-hidden bg-white/[0.02] border-white/5">
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 border-b border-white/5">
                <div className="p-8 border-r border-white/5 space-y-2">
                  <span className="label-uppercase opacity-40">{language === 'id' ? 'Holding Terbesar' : 'Largest Holding'}</span>
                  <p className="font-medium text-lg">{riskSimulation.largest_holding}</p>
                </div>
                <div className="p-8 border-r border-white/5 space-y-2">
                  <span className="label-uppercase opacity-40">{language === 'id' ? 'Skenario' : 'Scenario'}</span>
                  <p className="font-medium text-lg">{riskSimulation.scenario}</p>
                </div>
                <div className="p-8 border-r border-white/5 space-y-2">
                  <span className="label-uppercase opacity-40">{language === 'id' ? 'Dampak %' : 'Impact %'}</span>
                  <p className="font-medium text-lg numeric-value text-red-400">
                    {riskSimulation.nominal_impact !== null ? `${formatSafeSigned(riskSimulation.impact_percent)}%` : (
                      <span className="text-sm font-normal text-slate-500">
                        {language === 'id' ? 'Sedang dianalisis...' : 'Analyzing...'}
                      </span>
                    )}
                  </p>
                </div>
                <div className="p-8 space-y-2">
                  <span className="label-uppercase opacity-40">{language === 'id' ? 'Dampak Nominal' : 'Nominal Impact'}</span>
                  <p className="font-medium text-lg numeric-value">
                    {riskSimulation.nominal_impact !== null ? `-${safeDisplayCurrency(riskSimulation.nominal_impact, displayCurrency)}` : (
                      <span className="text-sm font-normal text-slate-500 leading-snug block mt-1">
                        {language === 'id' ? 'Dampak belum dapat dihitung dari data saat ini.' : 'Impact cannot be calculated from the current data yet.'}
                      </span>
                    )}
                  </p>
                </div>
              </div>
              <div className="p-8 bg-white/[0.01]">
                <p className="body-text text-slate-400 italic leading-relaxed">
                  "{riskSimulation.interpretation}"
                </p>
              </div>
            </div>

            {/* PRO: multi-scenario table */}
            <ProGate title="Simulasi skenario lebih dalam: -3%, -5%, dan -10%" userPlan={userPlan}>
              <div className="premium-card p-0 overflow-hidden bg-white/[0.02] border-white/5">
                <div className="px-8 pt-6 pb-4 border-b border-white/5">
                  <span className="label-uppercase opacity-50">Skenario Lanjutan</span>
                </div>
                <div className="overflow-x-auto">
                  <table className="w-full text-sm">
                    <thead>
                      <tr className="border-b border-white/5">
                        <th className="text-left p-4 px-8 label-uppercase opacity-40 font-normal">Skenario</th>
                        <th className="text-right p-4 label-uppercase opacity-40 font-normal">Dampak %</th>
                        <th className="text-right p-4 px-8 label-uppercase opacity-40 font-normal">Estimasi Kerugian</th>
                      </tr>
                    </thead>
                    <tbody>
                      {[3, 5, 10].map(pct => {
                        const impact = (enrichedSummary.totalCurrentValue * (pct / 100))
                        const portfolioImpact = riskSimulation.impact_percent
                          ? (pct / 5) * riskSimulation.impact_percent
                          : -pct
                        return (
                          <tr key={pct} className="border-b border-white/[0.04] hover:bg-white/[0.03]">
                            <td className="p-4 px-8 font-mono text-slate-300">Turun {pct}%</td>
                            <td className="p-4 text-right numeric-value text-red-400">{formatSafeSigned(portfolioImpact)}%</td>
                            <td className="p-4 px-8 text-right numeric-value text-slate-300">-{safeDisplayCurrency(impact, displayCurrency)}</td>
                          </tr>
                        )
                      })}
                    </tbody>
                  </table>
                </div>
                <div className="px-8 py-4 bg-white/[0.01]">
                  <p className="text-xs text-slate-500 leading-relaxed">Estimasi berdasarkan bobot holding terbesar. Pasar nyata bisa berbeda.</p>
                </div>
              </div>
            </ProGate>
          </section>
        )}

        {/* PRO: Portfolio Sensitivity per asset */}
        {enrichedHoldings.length > 0 && (
          <section className="space-y-8 animate-in fade-in duration-1000">
            <div className="space-y-2">
              <span className="label-uppercase">{language === 'id' ? 'Sensitivitas' : 'Sensitivity'}</span>
              <h3 className="text-2xl font-medium tracking-tight">{language === 'id' ? 'Kontribusi per Aset' : 'Contribution by Asset'}</h3>
            </div>
            <ProGate title={language === 'id' ? 'Lihat seberapa besar tiap aset memengaruhi pergerakan total portofolio' : 'See how much each asset affects total portfolio movement'} userPlan={userPlan}>
              <div className="space-y-3">
                {enrichedHoldings
                  .slice()
                  .sort((a, b) => (b.currentValue || 0) - (a.currentValue || 0))
                  .map(h => {
                    const weight = enrichedSummary.totalCurrentValue > 0
                      ? (h.currentValue / enrichedSummary.totalCurrentValue) * 100
                      : 0
                    const sensitivity = weight * 0.05 // 5% move on this asset
                    return (
                      <div key={h.id} className="premium-card flex items-center gap-6 bg-white/[0.02]">
                        <div className="w-10 h-10 rounded-xl bg-white/5 border border-white/10 flex items-center justify-center font-bold text-teal-400 text-xs flex-shrink-0">
                          {h.symbol.slice(0, 2)}
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="font-semibold text-sm">{h.symbol}</p>
                          <div className="flex items-center gap-2 mt-1.5">
                            <div className="flex-1 h-1.5 bg-white/5 rounded-full overflow-hidden">
                              <div
                                className="h-full bg-teal-500/60 rounded-full"
                                style={{ width: `${Math.min(weight, 100)}%` }}
                              />
                            </div>
                            <span className="text-xs font-mono text-slate-400 tabular-nums">{formatSafePercent(weight, 1)}</span>
                          </div>
                        </div>
                        <div className="text-right flex-shrink-0">
                          <p className="text-xs text-slate-500">{language === 'id' ? 'Jika turun 5%' : 'If down 5%'}</p>
                          <p className="text-sm font-mono text-red-400 mt-0.5">-{formatSafePercent(sensitivity, 2)}</p>
                        </div>
                      </div>
                    )
                  })
                }
              </div>
            </ProGate>
          </section>
        )}

        <section className="animate-in fade-in duration-1000">
          <AiChat
            sectionId="portfolio-ask-ting-ai"
            variant="panel"
            language={language}
            portfolio={normalizedPortfolio}
            userPlan="pro"
            analysisStatus={{
              label: 'Portfolio-aware',
              detail: 'Analisis menggunakan data portofolio riil.'
            }}
          />
        </section>

        <section className="space-y-10">
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-6">
            <div className="space-y-2">
              <span className="label-uppercase">Manajemen Aset</span>
              <h3 className="text-2xl font-medium tracking-tight">Daftar Posisi</h3>
            </div>
            <div className="flex gap-3">
              <button 
                className="premium-button px-5 py-3 bg-white/[0.05] text-white border border-white/10 font-medium rounded-2xl hover:bg-white/10 transition-all text-sm"
                onClick={restoreDefaultPositions}
              >
                Muat portofolio bawaan
              </button>
              <button 
                className="premium-button px-6 py-3 bg-white text-black font-semibold rounded-2xl hover:bg-teal-400 transition-all text-sm shadow-lg shadow-white/5"
                onClick={() => {
                  setEditingHoldingId(null);
                  setForm(initialForm);
                  document.getElementById('portfolio-form-section')?.scrollIntoView({ behavior: 'smooth' });
                }}
              >
                Tambah Posisi Baru
              </button>
            </div>
          </div>

          <div className="space-y-4">
            {enrichedHoldings.length ? enrichedHoldings.map(holding => (
              <div key={holding.id} className="premium-card flex flex-col lg:flex-row lg:items-center justify-between gap-8 hover:bg-white/[0.07]">
                <div className="flex items-center gap-6 min-w-[240px]">
                  <div className="w-12 h-12 rounded-2xl bg-white/5 border border-white/10 flex items-center justify-center font-bold text-teal-400">
                    {holding.symbol.slice(0, 2)}
                  </div>
                  <div>
                    <div className="font-semibold text-lg tracking-tight flex items-center gap-2">
                      {holding.symbol}
                      {getStatusBadge(holding.status, language)}
                    </div>
                    <p className="text-xs text-slate-500 font-mono mt-0.5">{holding.assetType} • {holding.region}</p>
                  </div>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-4 gap-8 flex-1">
                  <div>
                    <span className="label-uppercase opacity-40 text-[10px]">Kuantitas</span>
                    <p className="numeric-value mt-1">{isSafeNumber(holding.quantity) ? holding.quantity : '—'}</p>
                  </div>
                  <div>
                    <span className="label-uppercase opacity-40 text-[10px]">Entry</span>
                    <p className="numeric-value mt-1">{safeDisplayCurrency(holding.entryPrice, holding.entryCurrency)}</p>
                  </div>
                  <div>
                    <span className="label-uppercase opacity-40 text-[10px]">Terbaru</span>
                    <p className={`numeric-value mt-1 ${holding.status === 'fallback' ? 'opacity-80' : ''}`}>
                      {holding.status === 'error' ? '—' : safeDisplayCurrency(holding.latestPrice, holding.assetCurrency)}
                    </p>
                    {/* Show ≈ converted value when asset currency differs from base */}
                    {holding.status !== 'error' && holding.assetCurrency !== baseCurrency && isSafeNumber(holding.currentValue) && (
                      <p className="text-[10px] text-slate-500 mt-0.5 font-mono">
                        ≈ {safeDisplayCurrency(holding.currentValue / Math.max(holding.quantity, 1), baseCurrency)}
                      </p>
                    )}
                    {holding.status === 'fallback' && <p className="text-xs text-slate-500 mt-1">berdasarkan estimasi</p>}
                    {holding.status === 'delayed' && <p className="text-xs text-slate-500 mt-1">data tertunda</p>}
                    {holding.status === 'error' && <p className="text-xs text-slate-500 mt-1">data tidak tersedia</p>}
                  </div>
                  <div>
                    <span className="label-uppercase opacity-40 text-[10px]">
                      {holding.status === 'fallback' ? 'PnL (estimasi)' : 'PnL'}
                    </span>
                    <p className={`numeric-value mt-1 ${holding.status === 'error' ? 'text-slate-500' : holding.pnl >= 0 ? 'text-teal-400' : 'text-red-400'}`}>
                      {holding.status === 'error' ? '—' : `${formatSafeSigned(holding.pnlPct)}%`}
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-2 border-t lg:border-t-0 pt-4 lg:pt-0 border-white/5">
                  <button className="p-2 text-slate-500 hover:text-white transition-colors" onClick={() => handleStartEdit(holding)}>
                    <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" /></svg>
                  </button>
                  <button className="p-2 text-slate-500 hover:text-red-400 transition-colors" onClick={() => handleDeleteHolding(holding.id)}>
                    <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" /></svg>
                  </button>
                </div>
              </div>
            )) : (
              <div className="premium-card text-center py-20 bg-white/[0.01] border-dashed border border-white/10 rounded-3xl">
                <p className="text-slate-400 font-medium">Belum ada posisi.</p>
                <p className="text-slate-500 text-sm mt-2">Tambahkan aset pertama untuk mulai membaca portofoliomu.</p>
              </div>
            )}
          </div>
        </section>

        {/* Upgrade CTA — only shown to free users */}
        {userPlan === 'free' && (
          <div className="max-w-3xl mx-auto">
            <UpgradeSection />
          </div>
        )}

        <section id="portfolio-form-section" className="max-w-3xl mx-auto animate-in fade-in duration-1000">
           <div className="premium-card p-8 md:p-12 space-y-10 bg-white/[0.03]">
              <div className="text-center space-y-2">
                <span className="label-uppercase">{editingHoldingId ? 'Mode Edit' : 'Pencatatan Baru'}</span>
                <h3 className="text-2xl font-medium tracking-tight">{editingHoldingId ? 'Ubah Detail Posisi' : 'Tambah Posisi Portofolio'}</h3>
              </div>

              <form className="space-y-8" onSubmit={handleSubmit}>
                <div className="grid md:grid-cols-3 gap-8">
                  <div className="space-y-4">
                    <label className="label-uppercase opacity-60">Simbol Aset</label>
                    <input 
                      className="w-full bg-[#0f1116] border border-white/10 rounded-2xl px-6 py-4 text-white focus:outline-none focus:border-teal-500/40 transition-colors font-mono uppercase"
                      type="text"
                      placeholder="e.g. BBCA.JK atau XAU"
                      value={form.symbol} 
                      onChange={e => setForm(p => ({ ...p, symbol: e.target.value.toUpperCase() }))} 
                      required
                    />
                  </div>
                  <div className="space-y-4">
                    <label className="label-uppercase opacity-60">Kategori</label>
                    <select 
                      className="w-full bg-[#0f1116] border border-white/10 rounded-2xl px-6 py-4 text-white focus:outline-none focus:border-teal-500/40 transition-colors"
                      value={form.assetType} 
                      onChange={e => setForm(p => ({ ...p, assetType: e.target.value as any }))} 
                      required
                    >
                      <option value="stock">Saham</option>
                      <option value="commodity">Komoditas</option>
                      <option value="crypto">Kripto</option>
                    </select>
                  </div>
                  <div className="space-y-4">
                    <label className="label-uppercase opacity-60">Wilayah</label>
                    <select 
                      className="w-full bg-[#0f1116] border border-white/10 rounded-2xl px-6 py-4 text-white focus:outline-none focus:border-teal-500/40 transition-colors"
                      value={form.region} 
                      onChange={e => setForm(p => ({ ...p, region: e.target.value as any }))} 
                      required
                    >
                      <option value="ID">Indonesia (ID)</option>
                      <option value="GLOBAL">Global</option>
                    </select>
                  </div>
                </div>

                <div className="grid md:grid-cols-3 gap-8">
                  <div className="space-y-4">
                    <label className="label-uppercase opacity-60">Kuantitas / Lot</label>
                    <input 
                      className="w-full bg-[#0f1116] border border-white/10 rounded-2xl px-6 py-4 text-white focus:outline-none focus:border-teal-500/40 transition-colors font-mono"
                      type="number" 
                      step="any" 
                      placeholder="0.00"
                      value={form.quantity} 
                      onChange={e => setForm(p => ({ ...p, quantity: e.target.value }))} 
                      required 
                    />
                  </div>
                  <div className="space-y-4">
                    <label className="label-uppercase opacity-60">Harga Rata-Rata</label>
                    <input 
                      className="w-full bg-[#0f1116] border border-white/10 rounded-2xl px-6 py-4 text-white focus:outline-none focus:border-teal-500/40 transition-colors font-mono"
                      type="number" 
                      step="any" 
                      placeholder="0.00"
                      value={form.entryPrice} 
                      onChange={e => setForm(p => ({ ...p, entryPrice: e.target.value }))} 
                      required 
                    />
                  </div>
                  <div className="space-y-4">
                    <label className="label-uppercase opacity-60">Mata Uang</label>
                    <select 
                      className="w-full bg-[#0f1116] border border-white/10 rounded-2xl px-6 py-4 text-white focus:outline-none focus:border-teal-500/40 transition-colors"
                      value={form.entryCurrency} 
                      onChange={e => setForm(p => ({ ...p, entryCurrency: e.target.value as any }))} 
                      required
                    >
                      <option value="IDR">IDR</option>
                      <option value="USD">USD</option>
                    </select>
                  </div>
                </div>

                <div className="pt-4 flex flex-col sm:flex-row gap-4">
                  <button className="premium-button flex-1 py-4 bg-white text-black font-bold rounded-2xl hover:bg-teal-400 transition-all shadow-xl shadow-white/5" type="submit">
                    {editingHoldingId ? 'Simpan Perubahan' : 'Tambahkan ke Portofolio'}
                  </button>
                  {editingHoldingId && (
                    <button className="px-8 py-4 bg-white/5 text-white font-semibold rounded-2xl hover:bg-white/10 transition-all" type="button" onClick={handleCancelEdit}>
                      Batal
                    </button>
                  )}
                </div>
              </form>
           </div>
        </section>

        <section className="pt-12 border-t border-white/5">
          <div className="flex flex-col md:flex-row justify-between items-start gap-12">
            <div className="max-w-sm space-y-4">
              <span className="label-uppercase text-slate-600">Catatan Data</span>
              <p className="text-xs text-slate-500 leading-relaxed font-mono">
                Portofolio ini disimpan secara lokal di perangkat Anda demi privasi dan kecepatan. Kalkulasi AI diproses secara real-time.
              </p>
            </div>
            <p className="text-[10px] font-mono text-slate-700 md:text-right">
              Ting AI Intelligence Hub · Personal Workspace · v2.0
            </p>
          </div>
        </section>
      </main>
    </div>
  )
}
