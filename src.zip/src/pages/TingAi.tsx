import React, { useEffect, useState, useCallback } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { Link } from 'react-router-dom'
import HeroInput     from '../components/ting-ai-v2/HeroInput'
import InsightPanel  from '../components/ting-ai-v2/InsightPanel'
import { fetchIndonesianStocks } from '../lib/stockService'
import type { DetailedStockData } from '../lib/stockService'
import MarketSnapshot from '../components/ting-ai-v2/MarketSnapshot'
import StockChart    from '../components/ting-ai-v2/StockChart'
import { analyzePortfolio, parsePortfolio } from '../engine/analyzePortfolio'
import type { AnalysisResult, Holding } from '../engine/analyzePortfolio'
import { useAuthSession } from '../utils/useAuthSession'
import { hasProAccess } from '../utils/entitlements'
import { useLanguagePreference } from '../utils/language'

// ─────────────────────────────────────────────────────────────────────
// Design tokens (inline — Tailwind-independent)
// ─────────────────────────────────────────────────────────────────────
const C = {
  bg:       '#0b0d12',
  surface:  'rgba(255,255,255,0.025)',
  border:   'rgba(255,255,255,0.07)',
  teal:     '#14b8a6',
  amber:    '#f59e0b',
  slate400: '#94a3b8',
  slate500: '#64748b',
  slate600: '#475569',
  slate700: '#334155',
  white:    '#ffffff',
  mono:     "'SF Mono', 'Fira Mono', 'JetBrains Mono', monospace",
}

// ─────────────────────────────────────────────────────────────────────
// IHSG Summary Card
// ─────────────────────────────────────────────────────────────────────
function IhsgCard({ quotes }: { quotes: DetailedStockData[] }) {
  const { language: lang } = useLanguagePreference()
  const bullish   = quotes.filter(q => q.changePercent >= 0).length
  const bearish   = quotes.filter(q => q.changePercent <  0).length
  const avgChange = quotes.length > 0
    ? quotes.reduce((s, q) => s + q.changePercent, 0) / quotes.length
    : 0
  const sentiment  = avgChange > 0.5 ? 'Bullish' : avgChange < -0.5 ? 'Bearish' : (lang === 'id' ? 'Netral' : 'Neutral')
  const sentColor  = avgChange > 0.5 ? '#22d3ee' : avgChange < -0.5 ? '#f87171' : C.slate400
  const sentBg     = avgChange > 0.5 ? 'rgba(34,211,238,0.08)' : avgChange < -0.5 ? 'rgba(248,113,113,0.08)' : 'rgba(148,163,184,0.08)'

  if (!quotes.length) return null

  return (
    <motion.div
      initial={{ opacity: 0, y: 14 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.7 }}
      style={{
        borderRadius: 16, border: `1px solid ${C.border}`,
        background: C.surface, padding: '20px 24px',
        display: 'flex', flexDirection: 'column', gap: 18,
      }}
    >
      {/* header */}
      <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', gap: 12 }}>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 3 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
            <span style={{ fontFamily: C.mono, fontSize: 10, textTransform: 'uppercase', letterSpacing: '0.18em', color: C.slate500 }}>IDX / IHSG</span>
            <div style={{ display: 'flex', alignItems: 'center', gap: 5, fontFamily: C.mono, fontSize: 10, color: C.teal }}>
              <div style={{ width: 5, height: 5, borderRadius: '50%', background: C.teal }} />
              Live
            </div>
          </div>
          <p style={{ margin: 0, fontSize: 12, color: C.slate500 }}>
            {lang === 'id' ? 'Konteks pasar Indonesia hari ini' : 'Indonesian market context today'}
          </p>
        </div>
        <div style={{ fontFamily: C.mono, fontSize: 11, fontWeight: 700, padding: '4px 12px', borderRadius: 99, background: sentBg, color: sentColor, whiteSpace: 'nowrap' }}>
          {sentiment}
        </div>
      </div>

      {/* stats */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 10 }}>
        {[
          { value: bullish,   label: lang === 'id' ? 'Naik' : 'Up',    color: '#22d3ee' },
          { value: bearish,   label: lang === 'id' ? 'Turun' : 'Down',   color: '#f87171' },
          { value: `${avgChange >= 0 ? '+' : ''}${avgChange.toFixed(2)}%`, label: lang === 'id' ? 'Rata-rata' : 'Average', color: sentColor },
        ].map(({ value, label, color }) => (
          <div key={label} style={{
            borderRadius: 12, border: '1px solid rgba(255,255,255,0.05)',
            background: 'rgba(255,255,255,0.02)', padding: '12px 8px', textAlign: 'center',
          }}>
            <div style={{ fontFamily: C.mono, fontSize: 20, fontWeight: 700, color }}>{value}</div>
            <div style={{ fontFamily: C.mono, fontSize: 10, color: C.slate500, textTransform: 'uppercase', letterSpacing: '0.1em', marginTop: 3 }}>{label}</div>
          </div>
        ))}
      </div>

      {/* movers */}
      <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
        <span style={{ fontFamily: C.mono, fontSize: 10, color: C.slate600, textTransform: 'uppercase', letterSpacing: '0.2em' }}>{lang === 'id' ? 'Pergerakan signifikan' : 'Notable moves'}</span>
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6 }}>
          {[...quotes]
            .sort((a, b) => Math.abs(b.changePercent) - Math.abs(a.changePercent))
            .slice(0, 6)
            .map(q => (
              <div key={q.yahooSymbol} style={{
                display: 'flex', alignItems: 'center', gap: 5,
                fontFamily: C.mono, fontSize: 11,
                padding: '4px 10px', borderRadius: 8,
                background: 'rgba(255,255,255,0.02)', border: '1px solid rgba(255,255,255,0.05)',
              }}>
                <span style={{ color: C.slate400 }}>{q.symbol}</span>
                <span style={{ color: q.changePercent >= 0 ? '#22d3ee' : '#f87171' }}>
                  {q.changePercent >= 0 ? '+' : ''}{q.changePercent.toFixed(2)}%
                </span>
              </div>
            ))}
        </div>
      </div>

      <p style={{ margin: 0, fontFamily: C.mono, fontSize: 10, color: C.slate700, borderTop: '1px solid rgba(255,255,255,0.05)', paddingTop: 12 }}>
        {lang === 'id'
          ? `Berdasarkan ${quotes.length} emiten IDX - bukan rekomendasi investasi`
          : `Based on ${quotes.length} IDX stocks - not investment advice`}
      </p>
    </motion.div>
  )
}

// ─────────────────────────────────────────────────────────────────────
// Free / Pro Capability Row
// ─────────────────────────────────────────────────────────────────────
function CapabilityRow() {
  const { language: lang } = useLanguagePreference()
  const free = lang === 'id'
    ? ['Analisis dasar portofolio', 'Nilai dan komposisi', 'Label risiko', 'Konteks IHSG']
    : ['Basic portfolio analysis', 'Value and composition', 'Risk label', 'IHSG context']
  const pro  = lang === 'id'
    ? ['Intelligence Layer', 'Mengapa ini terjadi', 'Dampak detail', 'Skenario risiko', 'Konteks keputusan']
    : ['Intelligence Layer', 'Why this is happening', 'Portfolio impact detail', 'Risk scenario', 'Decision context']

  const chip = (text: string, color: string, bg: string, border: string) => (
    <span key={text} style={{ fontFamily: C.mono, fontSize: 10, padding: '3px 9px', borderRadius: 6, background: bg, color, border: `1px solid ${border}` }}>
      {text}
    </span>
  )

  return (
    <div style={{ display: 'flex', gap: 14, flexWrap: 'wrap' }}>
      {/* Free */}
      <div style={{
        flex: 1, minWidth: 220,
        borderRadius: 12, border: '1px solid rgba(20,184,166,0.18)',
        background: 'rgba(20,184,166,0.04)', padding: 16,
        display: 'flex', flexDirection: 'column', gap: 10,
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <div style={{ width: 14, height: 14, borderRadius: '50%', border: '1.5px solid rgba(20,184,166,0.5)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            <div style={{ width: 5, height: 5, borderRadius: '50%', background: C.teal }} />
          </div>
          <span style={{ fontFamily: C.mono, fontSize: 10, fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.2em', color: C.teal }}>{lang === 'id' ? 'Gratis' : 'Free'}</span>
        </div>
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: 5 }}>
          {free.map(f => chip(f, 'rgba(20,184,166,0.85)', 'rgba(20,184,166,0.1)', 'rgba(20,184,166,0.12)'))}
        </div>
      </div>

      {/* Pro */}
      <div style={{
        flex: 1, minWidth: 220,
        borderRadius: 12, border: '1px solid rgba(245,158,11,0.18)',
        background: 'rgba(245,158,11,0.04)', padding: 16,
        display: 'flex', flexDirection: 'column', gap: 10,
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <svg width="13" height="13" fill={C.amber} viewBox="0 0 24 24">
            <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/>
          </svg>
          <span style={{ fontFamily: C.mono, fontSize: 10, fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.2em', color: C.amber }}>Pro</span>
        </div>
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: 5 }}>
          {pro.map(f => chip(f, 'rgba(245,158,11,0.85)', 'rgba(245,158,11,0.1)', 'rgba(245,158,11,0.12)'))}
        </div>
      </div>
    </div>
  )
}

// ─────────────────────────────────────────────────────────────────────
// Analysis Loading Skeleton
// ─────────────────────────────────────────────────────────────────────
function AnalysisLoading() {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
      <div style={{ height: 100, borderRadius: 16, background: 'rgba(255,255,255,0.03)', border: '1px solid rgba(255,255,255,0.05)', animation: 'pulse 1.5s infinite' }} />
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 12 }}>
        {[0, 1, 2].map(i => (
          <div key={i} style={{ height: 130, borderRadius: 16, background: 'rgba(255,255,255,0.02)', border: '1px solid rgba(255,255,255,0.05)', animation: 'pulse 1.5s infinite' }} />
        ))}
      </div>
    </div>
  )
}

// ─────────────────────────────────────────────────────────────────────
// Section Divider Label
// ─────────────────────────────────────────────────────────────────────
function Divider({ label }: { label: string }) {
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
      <div style={{ flex: 1, height: 1, background: 'rgba(255,255,255,0.05)' }} />
      <span style={{ fontFamily: C.mono, fontSize: 9, textTransform: 'uppercase', letterSpacing: '0.25em', color: C.slate600 }}>{label}</span>
      <div style={{ flex: 1, height: 1, background: 'rgba(255,255,255,0.05)' }} />
    </div>
  )
}

// ─────────────────────────────────────────────────────────────────────
// Main Page
// ─────────────────────────────────────────────────────────────────────
export default function TingAi() {
  const { authenticated, user } = useAuthSession()
  const isPro = hasProAccess(user)
  const { language: lang } = useLanguagePreference()

  const [quotes, setQuotes]             = useState<DetailedStockData[]>([])
  const [quotesLoading, setQuotesLoading] = useState(true)
  const [selectedTicker, setSelectedTicker] = useState('BBCA.JK')

  const [analysisLoading, setAnalysisLoading] = useState(false)
  const [result, setResult]             = useState<AnalysisResult | null>(null)
  const [holdings, setHoldings]         = useState<Holding[]>([])
  const [showPanel, setShowPanel]       = useState(false)

  // Load market data ───────────────────────────────────────────────
  const loadMarketData = useCallback(() => {
    fetchIndonesianStocks()
      .then(data => { if (data.length > 0) setQuotes(data); setQuotesLoading(false) })
      .catch(() => setQuotesLoading(false))
  }, [])

  useEffect(() => {
    loadMarketData()
    const id = setInterval(loadMarketData, 30000)
    return () => clearInterval(id)
  }, [loadMarketData])

  // Handle analysis ────────────────────────────────────────────────
  const handleAnalyze = useCallback((input: string) => {
    setAnalysisLoading(true)
    setShowPanel(false)

    setTimeout(() => {
      const mkt     = quotes.map(q => ({ ticker: q.yahooSymbol.replace('.JK', ''), changePercent: q.changePercent }))
      const parsed  = parsePortfolio(input)
      const outcome = analyzePortfolio(input, mkt, lang)

      setHoldings(parsed)
      setResult(outcome)
      setShowPanel(true)
      setAnalysisLoading(false)

      setTimeout(() => document.getElementById('ai-result-section')?.scrollIntoView({ behavior: 'smooth', block: 'start' }), 300)
    }, 1400)
  }, [quotes, lang])

  const selectedQuote = quotes.find(q => q.yahooSymbol === selectedTicker)
  const isFallback    = quotes.some(q => (q as any).status === 'fallback')

  return (
    <div style={{ minHeight: '100vh', background: C.bg, color: C.white, overflowX: 'hidden', fontFamily: 'Inter, system-ui, sans-serif' }}>

      {/* ══ TOPNAV ══════════════════════════════════════════════════ */}
      <nav style={{
        position: 'fixed', top: 0, left: 0, right: 0, zIndex: 50,
        background: 'rgba(11,13,18,0.8)', backdropFilter: 'blur(20px)',
        borderBottom: '1px solid rgba(255,255,255,0.06)',
      }}>
        <div style={{
          maxWidth: 1100, margin: '0 auto', padding: '12px 24px',
          display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 16,
        }}>
          {/* Back */}
          <Link to="/" style={{
            display: 'flex', alignItems: 'center', gap: 6, textDecoration: 'none',
            fontFamily: C.mono, fontSize: 11, textTransform: 'uppercase', letterSpacing: '0.15em',
            color: C.slate500,
          }}>
            <svg width="14" height="14" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M15 19l-7-7 7-7"/>
            </svg>
            {lang === 'id' ? 'Kembali' : 'Back'}
          </Link>

          {/* Logo badge */}
          <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
            <div style={{
              width: 22, height: 22, borderRadius: 7,
              background: 'rgba(245,158,11,0.12)', border: '1px solid rgba(245,158,11,0.2)',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
            }}>
              <svg width="10" height="10" fill={C.amber} viewBox="0 0 24 24">
                <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/>
              </svg>
            </div>
            <span style={{ fontFamily: C.mono, fontSize: 10, textTransform: 'uppercase', letterSpacing: '0.2em', color: C.slate500 }}>Ting AI</span>
          </div>

          {/* Auth actions */}
          <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
            {!authenticated && (
              <Link to="/login" style={{
                fontFamily: C.mono, fontSize: 11, textTransform: 'uppercase', letterSpacing: '0.15em',
                color: C.slate500, textDecoration: 'none',
              }}>
                {lang === 'id' ? 'Masuk' : 'Login'}
              </Link>
            )}
            <Link to="/upgrade" style={{
              fontFamily: C.mono, fontSize: 11, fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.12em',
              padding: '6px 14px', borderRadius: 8,
              border: '1px solid rgba(245,158,11,0.25)', background: 'rgba(245,158,11,0.08)',
              color: C.amber, textDecoration: 'none',
            }}>
              {lang === 'id' ? 'Lihat Pro' : 'View Pro'}
            </Link>
          </div>
        </div>
      </nav>

      {/* ══ MAIN ══════════════════════════════════════════════════════ */}
      <main style={{ maxWidth: 1000, margin: '0 auto', padding: '96px 24px 96px', display: 'flex', flexDirection: 'column', gap: 80 }}>

        {/* ── 1. HERO ─────────────────────────────────────────────── */}
        <section style={{ display: 'flex', flexDirection: 'column', gap: 36, paddingTop: 24 }}>

          {/* Badge + heading */}
          <div style={{ display: 'flex', flexDirection: 'column', gap: 18, maxWidth: 680 }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
              <span style={{
                fontFamily: C.mono, fontSize: 10, textTransform: 'uppercase', letterSpacing: '0.2em',
                color: 'rgba(20,184,166,0.75)', border: '1px solid rgba(20,184,166,0.2)',
                background: 'rgba(20,184,166,0.06)', padding: '4px 12px', borderRadius: 99,
              }}>
                AI Portfolio Copilot
              </span>
              <span style={{ fontFamily: C.mono, fontSize: 10, textTransform: 'uppercase', letterSpacing: '0.18em', color: C.slate600 }}>
                Indonesia
              </span>
            </div>

            <h1 style={{ margin: 0, fontSize: 38, fontWeight: 600, letterSpacing: '-0.025em', lineHeight: 1.2, color: C.white }}>
              {lang === 'id' ? 'Pahami portofoliomu,' : 'Understand your portfolio,'}{' '}
              <span style={{ color: C.slate500 }}>
                {lang === 'id' ? 'bukan cuma market.' : 'not just the market.'}
              </span>
            </h1>

            <p style={{ margin: 0, fontSize: 15, color: C.slate400, lineHeight: 1.7, maxWidth: 580 }}>
              {lang === 'id' 
                ? 'Masukkan komposisi portofolio kamu. Ting AI membaca konsentrasi, eksposur risiko, dan konteks pasar saat ini tanpa memberi sinyal beli atau jual.'
                : 'Input your portfolio composition. Ting AI reads concentration, risk exposure, and current market context without providing buy or sell signals.'}
            </p>
          </div>

          {/* Capability chips */}
          <CapabilityRow />

          {/* Input */}
          <div style={{ position: 'relative' }}>
            <HeroInput onAnalyze={handleAnalyze} loading={analysisLoading} />
            {isFallback && (
              <p style={{ marginTop: 10, fontFamily: C.mono, fontSize: 10, color: C.slate600, letterSpacing: '0.1em' }}>
                {lang === 'id' ? 'Konteks pasar memakai estimasi karena data live belum tersinkron.' : 'Market context is using estimates because live data is not synced yet.'}
              </p>
            )}
          </div>
        </section>

        {/* ── 2. ANALYSIS RESULT ──────────────────────────────────── */}
        <AnimatePresence>
          {(showPanel || analysisLoading) && (
            <motion.section
              id="ai-result-section"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              style={{ display: 'flex', flexDirection: 'column', gap: 24 }}
            >
              <Divider label={lang === 'id' ? 'Hasil Analisis' : 'Analysis Result'} />

              {/* Insight headline */}
              {showPanel && result && !analysisLoading && (
                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.6 }}
                  style={{
                    borderRadius: 14, border: '1px solid rgba(255,255,255,0.07)',
                    background: 'rgba(255,255,255,0.02)', padding: '20px 24px',
                  }}
                >
                  <p style={{ margin: '0 0 8px', fontFamily: C.mono, fontSize: 9, textTransform: 'uppercase', letterSpacing: '0.25em', color: C.slate500 }}>
                    {lang === 'id' ? 'Wawasan Utama' : 'Key Insight'}
                  </p>
                  <p style={{ margin: 0, fontSize: 16, fontWeight: 500, color: C.white, lineHeight: 1.6 }}>
                    "{result.insight}"
                  </p>
                </motion.div>
              )}

              {/* Panel */}
              {analysisLoading
                ? <AnalysisLoading />
                : showPanel && result && (
                  <InsightPanel
                    result={result}
                    holdings={holdings}
                    visible={showPanel}
                    isPro={isPro}
                  />
                )
              }
            </motion.section>
          )}
        </AnimatePresence>

        {/* ── 3. IHSG MARKET CONTEXT ──────────────────────────────── */}
        <section style={{ display: 'flex', flexDirection: 'column', gap: 28 }}>

          {/* Section header */}
          <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
              <span style={{ fontFamily: C.mono, fontSize: 10, textTransform: 'uppercase', letterSpacing: '0.18em', color: C.slate500 }}>
                {lang === 'id' ? 'Konteks Pasar' : 'Market Context'}
              </span>
              {!quotesLoading && (
                <div style={{ display: 'flex', alignItems: 'center', gap: 5, fontFamily: C.mono, fontSize: 10, color: C.teal }}>
                  <div style={{ width: 5, height: 5, borderRadius: '50%', background: C.teal }} />
                  Live
                </div>
              )}
            </div>
            <h2 style={{ margin: 0, fontSize: 26, fontWeight: 600, letterSpacing: '-0.02em', color: C.white }}>
              {lang === 'id' ? 'Kondisi IDX hari ini' : 'IDX condition today'}
            </h2>
            <p style={{ margin: 0, fontSize: 14, color: C.slate500 }}>
              {lang === 'id' 
                ? 'IHSG membantu membaca tekanan pasar saham Indonesia, terutama jika portofoliomu berisi saham domestik.'
                : 'IHSG helps read Indonesian equity market pressure, especially when your portfolio contains domestic stocks.'}
            </p>
          </div>

          {/* IHSG card */}
          {!quotesLoading && quotes.length > 0 ? (
            <IhsgCard quotes={quotes} />
          ) : !quotesLoading ? (
            <div style={{
              borderRadius: 16,
              border: `1px solid ${C.border}`,
              background: C.surface,
              padding: 22,
              color: C.slate500,
              fontSize: 13,
            }}>
              {lang === 'id' ? 'Data IHSG belum tersedia.' : 'IHSG data is not available yet.'}
            </div>
          ) : null}

          <StockChart ticker="^JKSE" />

          {/* Stock grid */}
          <MarketSnapshot
            quotes={quotes}
            loading={quotesLoading}
            onSelectTicker={setSelectedTicker}
            selectedTicker={selectedTicker}
          />

          {/* Chart */}
          <StockChart
            ticker={selectedTicker}
            currentPrice={selectedQuote?.price}
            changePercent={selectedQuote?.changePercent}
          />
        </section>

        {/* ── 4. FOOTER NOTE ──────────────────────────────────────── */}
        <footer style={{
          borderTop: '1px solid rgba(255,255,255,0.05)',
          paddingTop: 32, display: 'flex', flexDirection: 'column', gap: 24,
        }}>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(260px, 1fr))', gap: 32 }}>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
              <h4 style={{ margin: 0, fontSize: 10, fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.2em', color: C.slate500 }}>
                {lang === 'id' ? 'Filosofi Analisis' : 'Analysis Philosophy'}
              </h4>
              <p style={{ margin: 0, fontSize: 12, color: C.slate600, lineHeight: 1.8 }}>
                {lang === 'id'
                  ? 'Ting AI membaca konsentrasi, korelasi sektoral, dan sensitivitas portofolio terhadap kondisi pasar. Investor ritel membutuhkan kejernihan, bukan sinyal transaksi.'
                  : 'Ting AI reads concentration, sector correlation, and portfolio sensitivity to market conditions. Retail investors need clarity, not transaction signals.'}
              </p>
            </div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
              <h4 style={{ margin: 0, fontSize: 10, fontWeight: 700, textTransform: 'uppercase', letterSpacing: '0.2em', color: C.slate500 }}>
                {lang === 'id' ? 'Metodologi Data' : 'Data Methodology'}
              </h4>
              <p style={{ margin: 0, fontSize: 12, color: C.slate600, lineHeight: 1.8 }}>
                {lang === 'id'
                  ? 'Harga disinkronkan berkala melalui sumber pasar publik. Seluruh analisis bersifat informatif dan bukan saran investasi.'
                  : 'Prices are refreshed periodically through public market sources. All analysis is informational and is not investment advice.'}
              </p>
            </div>
          </div>
          <p style={{ margin: 0, fontFamily: C.mono, fontSize: 10, color: C.slate700, textAlign: 'center', letterSpacing: '0.08em' }}>
            {lang === 'id'
              ? 'Ting AI - Intelligence Engine v2.1 - Dibangun oleh Faturachman Alkahfi - Bukan rekomendasi investasi'
              : 'Ting AI - Intelligence Engine v2.1 - Built by Faturachman Alkahfi - Not investment advice'}
          </p>
        </footer>
      </main>
    </div>
  )
}
