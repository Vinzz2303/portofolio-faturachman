/**
 * stockService.ts
 * Fetches stock data via backend API. No browser-side CORS proxy.
 * If backend is unavailable, returns error status (never fake data).
 */
import type { StockQuote } from '../services/yahooFinance'
import { getMarketQuote } from '../services/marketData'

export interface DetailedStockData {
  symbol: string
  yahooSymbol: string
  name: string
  price: number
  previousClose: number
  changePercent: number
  currency: string
  status: 'live' | 'delayed' | 'fallback' | 'error'
  source: string
  fetchedAt?: string
}

const STOCK_NAMES: Record<string, string> = {
  'BBCA.JK': 'Bank Central Asia Tbk.',
  'BBRI.JK': 'Bank Rakyat Indonesia Tbk.',
  'BMRI.JK': 'Bank Mandiri (Persero) Tbk.',
  'BBNI.JK': 'Bank Negara Indonesia Tbk.',
  'TLKM.JK': 'Telkom Indonesia Tbk.',
  'GOTO.JK': 'GoTo Gojek Tokopedia Tbk.',
  'ASII.JK': 'Astra International Tbk.',
  'ADRO.JK': 'Adaro Energy Indonesia Tbk.',
  'PTBA.JK': 'Bukit Asam Tbk.',
  'ANTM.JK': 'Aneka Tambang Tbk.',
  'ICBP.JK': 'Indofood CBP Sukses Makmur Tbk.',
  'INDF.JK': 'Indofood Sukses Makmur Tbk.',
  'UNVR.JK': 'Unilever Indonesia Tbk.',
  'GC=F': 'Gold (XAU)',
  'BTC-USD': 'Bitcoin (BTC)',
}

const IDX_SYMBOLS = [
  'BBCA.JK', 'BBRI.JK', 'BMRI.JK', 'BBNI.JK', 'TLKM.JK',
  'GOTO.JK', 'ASII.JK', 'ADRO.JK', 'PTBA.JK', 'ANTM.JK',
  'ICBP.JK', 'INDF.JK', 'UNVR.JK',
  'GC=F', 'BTC-USD',
]

/**
 * Map portfolio/display symbols → Yahoo Finance API symbols.
 * Portfolio stores "XAU", "BTC", "BBCA.JK" etc.
 * Yahoo Finance needs "GC=F", "BTC-USD", "BBCA.JK".
 */
const SYMBOL_MAP: Record<string, string> = {
  'XAU': 'GC=F',
  'XAUUSD': 'GC=F',
  'GOLD': 'GC=F',
  'BTC': 'BTC-USD',
  'BITCOIN': 'BTC-USD',
  'ETH': 'ETH-USD',
}

function toYahooSymbol(symbol: string): string {
  const upper = symbol.toUpperCase()
  // Check explicit commodity/crypto map
  if (SYMBOL_MAP[upper]) return SYMBOL_MAP[upper]
  // Pass through as-is — caller (Portfolio.tsx) is responsible for correct symbol
  return symbol
}

export async function fetchStock(yahooSymbol: string): Promise<DetailedStockData> {
  const apiSymbol = toYahooSymbol(yahooSymbol)
  const name = STOCK_NAMES[apiSymbol] || STOCK_NAMES[yahooSymbol] || yahooSymbol
  const displaySymbol = yahooSymbol.replace('.JK', '')
  const now = new Date().toISOString()

  try {
    const quote = await getMarketQuote(apiSymbol)

    if (!quote) {
      return {
        symbol: displaySymbol,
        yahooSymbol,
        name,
        price: 0,
        previousClose: 0,
        changePercent: 0,
        currency: 'IDR',
        status: 'error',
        source: 'Unavailable',
        fetchedAt: now,
      }
    }

    return {
      symbol: displaySymbol,
      yahooSymbol,
      name,
      price: quote.price,
      previousClose: quote.prevClose,
      changePercent: quote.changePercent,
      currency: quote.currency,
      status: 'delayed',
      source: 'Backend API',
      fetchedAt: now,
    }
  } catch {
    return {
      symbol: displaySymbol,
      yahooSymbol,
      name,
      price: 0,
      previousClose: 0,
      changePercent: 0,
      currency: 'IDR',
      status: 'error',
      source: 'Unavailable',
      fetchedAt: now,
    }
  }
}

export async function fetchIndonesianStocks(): Promise<DetailedStockData[]> {
  const results = await Promise.allSettled(IDX_SYMBOLS.map(fetchStock))

  return results.map((r, i) => {
    if (r.status === 'fulfilled') return r.value

    const yahooSymbol = IDX_SYMBOLS[i]
    return {
      symbol: yahooSymbol.replace('.JK', ''),
      yahooSymbol,
      name: STOCK_NAMES[yahooSymbol] || yahooSymbol,
      price: 0,
      previousClose: 0,
      changePercent: 0,
      currency: 'IDR',
      status: 'error' as const,
      source: 'Unavailable',
    }
  })
}

/**
 * Legacy compatibility layer
 */
export async function fetchStocks(): Promise<StockQuote[]> {
  const data = await fetchIndonesianStocks()
  return data
    .filter(s => s.status !== 'error' && s.price > 0)
    .map(s => ({
      ticker: s.yahooSymbol,
      price: s.price,
      changePercent: s.changePercent,
      change: s.price - s.previousClose,
      prevClose: s.previousClose,
      currency: s.currency,
    }))
}
